library(testthat)
library(rdflib)

test_check("rdflib")
